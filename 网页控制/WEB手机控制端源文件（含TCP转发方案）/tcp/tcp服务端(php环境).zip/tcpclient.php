<?php

set_time_limit(10);//���ó�ʱʱ��

$server="121.199.40.177";
$port=8080;



$getinput= $_POST['data'];
if($getinput=="")
{
	$getinput= $_GET['data'];
	if($getinput=="")
	{
		$getinput=file_get_contents("php://input"); 
	}
}
if($getinput==""){
	die("Error: Send message is null\n");
	exit;
}


$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP) or die("Error: Could not create socket\n");
$con=socket_connect($socket,$server,$port) or die("Error: Could not socket_connect server\n");
if(!$con){	
	socket_close($socket);
	exit;
}



//while($con)
{        

        $words=urldecode($getinput);//urlencode($getinput);//������������
        socket_write($socket,$words);
		
		$msg=socket_read($socket,1024);
        echo $msg;
        //if($msg=="bye\r\n"){break;}
}

socket_shutdown($socket);
socket_close($socket);

?>